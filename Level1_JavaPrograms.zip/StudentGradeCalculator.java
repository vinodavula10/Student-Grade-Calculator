import java.util.Scanner;

public class StudentGradeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("=== Student Grade Calculator ===");
        System.out.print("Enter the number of grades: ");
        int numGrades = scanner.nextInt();
        
        if (numGrades <= 0) {
            System.out.println("Number of grades must be greater than 0!");
            scanner.close();
            return;
        }
        
        double[] grades = new double[numGrades];
        double sum = 0;
        
        // Input grades
        for (int i = 0; i < numGrades; i++) {
            System.out.print("Enter grade " + (i + 1) + ": ");
            grades[i] = scanner.nextDouble();
            sum += grades[i];
        }
        
        // Calculate average
        double average = sum / numGrades;
        
        // Display results
        System.out.println("\n=== Results ===");
        System.out.printf("Average Grade: %.2f\n", average);
        
        // Display letter grade
        char letterGrade;
        if (average >= 90) {
            letterGrade = 'A';
        } else if (average >= 80) {
            letterGrade = 'B';
        } else if (average >= 70) {
            letterGrade = 'C';
        } else if (average >= 60) {
            letterGrade = 'D';
        } else {
            letterGrade = 'F';
        }
        
        System.out.println("Letter Grade: " + letterGrade);
        
        scanner.close();
    }
}
