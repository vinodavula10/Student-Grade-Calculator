import java.util.Scanner;
import java.util.Random;

public class RandomPasswordGenerator {
    
    public static String generatePassword(int length, boolean includeNumbers, 
                                         boolean includeLowercase, boolean includeUppercase, 
                                         boolean includeSpecial) {
        String numbers = "0123456789";
        String lowercase = "abcdefghijklmnopqrstuvwxyz";
        String uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String special = "!@#$%^&*()_+-=[]{}|;:,.<>?";
        
        StringBuilder characters = new StringBuilder();
        
        if (includeNumbers) characters.append(numbers);
        if (includeLowercase) characters.append(lowercase);
        if (includeUppercase) characters.append(uppercase);
        if (includeSpecial) characters.append(special);
        
        if (characters.length() == 0) {
            return "Error: Select at least one character type!";
        }
        
        Random random = new Random();
        StringBuilder password = new StringBuilder();
        
        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(characters.length());
            password.append(characters.charAt(randomIndex));
        }
        
        return password.toString();
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("=== Random Password Generator ===");
        System.out.print("Enter desired password length: ");
        int length = scanner.nextInt();
        
        if (length < 4) {
            System.out.println("Password length should be at least 4 characters!");
            scanner.close();
            return;
        }
        
        System.out.println("\nSelect character types to include:");
        
        System.out.print("Include numbers (0-9)? (y/n): ");
        boolean includeNumbers = scanner.next().equalsIgnoreCase("y");
        
        System.out.print("Include lowercase letters (a-z)? (y/n): ");
        boolean includeLowercase = scanner.next().equalsIgnoreCase("y");
        
        System.out.print("Include uppercase letters (A-Z)? (y/n): ");
        boolean includeUppercase = scanner.next().equalsIgnoreCase("y");
        
        System.out.print("Include special characters (!@#$%...)? (y/n): ");
        boolean includeSpecial = scanner.next().equalsIgnoreCase("y");
        
        // Generate password
        String password = generatePassword(length, includeNumbers, includeLowercase, 
                                          includeUppercase, includeSpecial);
        
        System.out.println("\n=== Generated Password ===");
        System.out.println("Password: " + password);
        
        scanner.close();
    }
}
